import java.io.File;

/**************************************************************
MyTree

Description: java version of the tree program for CS servers since we don't have that installed : (

Compilation: $ javac MyTree.java

Execution: $ java MyTree [-adf] [PATH]

Switches: 
    -a : show hidden files
    -d : only show directories
    -f : show full path name

@author Kevin Sun
@since 2019 Jan 15

**************************************************************/

public class MyTree {

    private File dir;
    private File[] subfiles;

    private int nbHiddenDirs;
    private int nbHiddenFiles;
    private int nbDirs;
    private int nbFiles;
    private String offsetString = "";
    
    private boolean all = false;
    private boolean dirOnly = false;
    private boolean fullPath = false;
    
    /*
    
     * 
     * -a     All  files  are printed.  By default tree does not print hidden files (those beginning with a dot `.').
              In no event does tree print the file system constructs  `.'  (current  directory)  and  `..'  (previous
              directory).

       -d     List directories only.
       
        -f     Prints the full path prefix for each file.
     */

    /**
     * Constructor 
     */
    public MyTree(String[] input) {
        processInput(input);
        subfiles = dir.listFiles();
        System.out.println( dir.getPath() );

    }
    
    /**
     * A method that gathers information such as the switches and the path from the input.
     * @param args is a String array 
     */
    private void processInput(String[] args) {
        switch(args.length) {
            case 0:
                dir = getDir(".");
                break;
            case 1:
                if(args[0].charAt(0) == '-') {
                    getSwitches(args[0]);
                    dir = getDir(".");
                }else {
                    dir = getDir(args[0]);
                }
                break;
            case 2:
                if(args[0].charAt(0) == '-') {
                    getSwitches(args[0]);
                }
                dir = getDir(args[1]);
                break;
            
            default:
                System.err.println("Invalid Input.");
                System.exit(-1);
        
        }
    }
    
    /**
     * Set switches
     * @param s is the args[0] from the arg list if it starts with -
     */
    private void getSwitches(String s) {
        all = s.contains("a");
        dirOnly = s.contains("d");
        fullPath = s.contains("f");
    }

    /**
     * Print the file tree and other information
     */
    public void printTree() {

        printTree(subfiles, offsetString);
        System.out.println();
        
        System.out.println(nbDirs + " directories, " + nbFiles + " files");
        System.out.println(nbHiddenDirs + " hidden directories, " + nbHiddenFiles + " hidden files");
    }

    /**
     * Print the file tree recursively
     * @param subfiles is the array of all the files/directories that are in the current dirctory
     * @param String offsetString is the string that contains the symbols such as vertical lines and tabs
     */
    private void printTree(File[] subfiles, String offsetString) {
        String fileName;
        int lastDirIndex = dirOnly ? lastDirIndex(subfiles) : 0;

        for (int i = 0; i < subfiles.length; i++) {

            fileName = fullPath ? subfiles[i].getAbsolutePath(): subfiles[i].getName();
            
            if(subfiles[i].isHidden() && !all) {
                int z = subfiles[i].isFile()? nbHiddenFiles++ : nbHiddenDirs++;
                continue;
            }

            if(dirOnly && subfiles[i].isFile()) {
                continue;
            }
                
                System.out.print(offsetString);
                
                if (i == subfiles.length - 1) {
                    if(dirOnly) {
                        if(i == lastDirIndex) {
                            System.out.println("\u2514\u2500\u2500 " + fileName); 
                        }else{
                            System.out.println("\u251c\u2500\u2500 " + fileName); 
                        }

                    }else{
                        System.out.println("\u2514\u2500\u2500 " + fileName); 
                    }
                    if (!subfiles[i].isFile()) {
                        if( subfiles[i].isHidden() ) nbHiddenDirs++;
                        nbDirs++;
                        printTree(subfiles[i].listFiles(), offsetString + "    ");
                    }else {
                        if( subfiles[i].isHidden() ) nbHiddenFiles++;
                        nbFiles++;
                    }
                    
                } else {
                    if(dirOnly) {
                        if(i == lastDirIndex) {
                            System.out.println("\u2514\u2500\u2500 " + fileName); 
                        }else{
                            System.out.println("\u251c\u2500\u2500 " + fileName); 
                        }

                    }else{
                        System.out.println("\u251c\u2500\u2500 " + fileName); 
                    }
                    if (!subfiles[i].isFile()) {
                        if( subfiles[i].isHidden() ) nbHiddenDirs++;
                        nbDirs++;

                       if(dirOnly) {
                            if(i == lastDirIndex) {
                                printTree(subfiles[i].listFiles(), offsetString + "   ");
                            }else{
                                printTree(subfiles[i].listFiles(), offsetString + "\u2502   ");
                            }
                        }else{
                            printTree(subfiles[i].listFiles(), offsetString + "\u2502   ");
                        }

                    }else {
                        if( subfiles[i].isHidden() ) nbHiddenFiles++;
                        nbFiles++;
                    }
                    
                }


        }
    }

    /**
     * Find and return the index of the last directory in the file array
     * @param files is the array of all the files/directories that are in the current dirctory
     * @return the index of the last directory of the array 
     */
    private int lastDirIndex(File[] files) {
        int i = files.length - 1;
        while(i > 0 && files[i].isFile()) {
            i--;
        }
        return i;
    }

    /**
     * Get the directory from the input string 
     * @param dir is the string that contains the path of the directory
     * @return a File object of the directory
     */
    private File getDir(String dir) {
        File file = null;
        file = new File(dir);

        if (!file.exists()) {
            System.err.println("The folder doesn't exist.");
            System.exit(-1);
        } else if (file.isFile()) {
            System.err.println("The input is not a folder.");
            System.exit(-1);
        } else {
            return file;
        }
        return file;
    }

    /**
     * main method 
     */
    public static void main(String[] args) {
        
        MyTree tree = new MyTree(args);
        tree.printTree();
    }
}
